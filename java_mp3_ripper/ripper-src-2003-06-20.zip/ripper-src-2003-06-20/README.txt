Installing the Ripper
---------------------

Requirements
------------
- installed JDK1.3 or higher (or 1.2 with tritonus)
- installed mp3 encoder plugin and installed cdda plugin
  download at http://www.tritonus.org/plugins.html


Compiling on Unix/Linux
-----------------------
1.  Make sure that tritonus_share.jar, tritonus_cdda.jar, and 
    tritonus_mp3 are in the CLASSPATH, or (better) in the
    JAVA_HOME/jre/lib/ext directory
2.  Make sure libcdparanoia.so is in the LD_LIBRARY_PATH,
    or in the JAVA_HOME/jre/lib/i386 directory.
2a. run "make compileinitial" (if first compile) or "make"
 -- or --
2b. run "ant"


If something doesn't work as it should
--------------------------------------
write to tritonus-user@lists.sourceforge.net
with a detailed problem description
  
Latest version on
http://www.jsresources.org/apps/ripper/

(c) 2002 by Florian Bomers, Matthias Pfisterer
